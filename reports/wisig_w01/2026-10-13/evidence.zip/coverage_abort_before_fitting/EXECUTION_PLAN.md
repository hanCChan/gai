# WiSig W0/W1：可信基准和可迁移变化结构

2026-10-13，北京时间。用户新附件和“理解方案，然后执行”授权本轮W0/W1；Shen rank2的停止决定不变，W2只提交条件决定与冻结计划，W3另批。来源Kaggle副本的官方字节一致性仍未证明。原ZIP以只读方式访问，不覆盖、不重下。

读取器只把三个NumPy构造入口替换为受审计的惰性buffer类，拒绝任意其他globals/persistent IDs。形状/dtype/字节长度验证后，仅在批准的未等化开发单元调用本地np.frombuffer。最终RX、最后日期、等化版的buffer只作为pickle结构被不透明读取，不转数值、不训练、不算统计；此区别明确披露，不宣称ZIP字节从未触及。

## 数据和冻结划分

按官方orbit_hardware元数据型号、开发前三日期的最小/总覆盖率降序、RX名字排序，循环分派source/source/internal/final，形成16源RX、8内部RX、8最终RX。硬件元数据不能证明天线、增益和其它配置一致，公开实际型号和缺失项，不把32RX当作32种硬件。名单由元数据决定，在任何模型结果前冻结。

日期0/1用于encoder学习与源内选checkpoint，日期2用于跨日期检验，日期3保留后续确认。八台TX（原列表索引0–7）用于encoder，两台TX（8/9）严格从encoder优化和变换拟合排除；沿用用户此前明确的严格排除要求。只有两个encoder，不能声称覆盖全部五个TX留出划分或已经充分检验十类分类。

每源RX×日期×训练TX前120个原位置包训练，位置120–159源内验证，160–199同RX独立包评价。验证、归一化和每包索引都公开事实；若无效数据破坏最低160包覆盖则在训练前停止，不重抽样补包。每包RMS是官方norm方式，无额外等化、CFO处理或频带变换。

## W0：最多两个作业

PyTorch逐层移植官方d003的CNN：同SAME padding、pooling、NHWC flatten次序、Dense100/80、Dropout0.5，八分类39940参数。Glorot uniform；Adam LR0.0005/epsilon1e-7，Dense核L2=0.0001，最多100轮，源内validation loss checkpoint与patience5（官方配方）。有记录的差别：Torch实现、八身份严格留出、RX×日期×TX均衡批次、指定独立日期/接收机划分；不是宣称逐比特复现作者结果。

两个种子20261013/20261014，无LR搜索，无拟合重试或种子替换；先第一作业计时，再同配方第二作业。每作业运行最长1800秒，最多两个作业，总最多1 reserved GPUh，保护运行而不是授权额外矩阵。合成输入CPU/GPU前向、反向和优化步骤必须先通过，防止再次将实现问题带入研究拟合。

可信encoder门槛：冻结模型在训练包的eval-mode Accuracy≥90%，源内验证≥85%，两个种子都通过才将W1解释为可信表征的机制证据；否则W1只是该不充分表征下的描述并HOLD W2。最终RX和日期不使用。内部RX的已见日期和未见日期结果在checkpoint冻结后一次性汇报，不用于任何调参。保留最终RX×已见日、已见RX×最终日、最终RX×最终日三类确认用途。

## W1：统计分解和留出预测

复用两个冻结encoder，80维特征，源16RX、10TX、前三日期，源日期0/1仅使用位置120–199（不使用encoder训练包），日期2使用全部有效包。按单元确定性奇偶位置分成两独立包子集，以原型重测误差评价抽样不确定性；它不是热噪声或独立IQ物理噪声估计。需至少40包的完整source TX×RX×日期矩阵，不因模型结果删除单元。

等权平衡cell原型做全因子统计分解：TX、RX、日期主效应，TX×RX、TX×日期、RX×日期及三阶交互。报告均方范数比例、奇偶重测稳定性和抽样不确定性基线，绝不称RX硬件因果效应。

全部240个源RX有向对；固定同日期训练外包检验、开发日期0→1和前两日期→留出日期2的预测。映射拟合仅八已见TX；严格两留出TX用其源分布作为查询，只用目标分布作评价。基本对照Identity、Translation、收缩0.1 CORAL；不复活rank2。

诊断额外模型：CORAL之后，用源八类原型中固定三个最近邻的目标残余均值平均作类条件修正，不拟合大矩阵，不搜索邻居数。它只是可预测剩余结构的检验，不声称原创算法。训练均值/协方差和所有方法的信息相同，包未配对。报告类均值距离、Gaussian W2²、以真实目标原型作参照的诊断检索和条件变换后八类分类的身份保持；目标原型检索不等于可部署精度。

W2条件：两个encoder可信；类条件修正相对最强固定简单控制在严格留出TX、留出日期上两个距离都改善至少5%，两留出TX分别成立且超过奇偶抽样不确定性；已见八类的冻结分类准确率比原输入下降不超过2个百分点，两个种子一致。源已知RX映射成功也不能推断恢复任意未知RX真实变换。没有这些证据则STOP/HOLD，不加Loss/Attention、更高rank或生成器；即使通过也只提交最多12模型的W2冻结建议及由试验计时估算的预算，本轮不执行。

## 必交付判断和出版

Shen失败：欠定性、统计信息不匹配与encoder能力各有证据，但现有设计不能分离其因果贡献；不能把WiSig成功反推Shen失败原因。WiSig统计比例、跨TX/日期可预测性、身份保持与W2条件分别报告。

核查直接竞争[RIEI](https://arxiv.org/abs/2411.03636)、[DRIFT v2](https://arxiv.org/abs/2510.09405)、[IB-RFF](https://signalprocessingsociety.org/publications-resources/ieee-transactions-information-forensics-and-security/2026/09/information)、[ConstStyle](https://openaccess.thecvf.com/content/ICCV2025/html/Tran_ConstStyle_Robust_Domain_Generalization_with_Unified_Style_Transformation_ICCV_2025_paper.html)，不凭摘要宣称原创。原信号、缓存、特征、权重和用户私稿不出版，出版SHA、协议、源代码、全部指标和证据索引到新分支，验证远端树、报告和决定后停止。
